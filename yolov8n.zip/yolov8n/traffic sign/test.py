import cv2
from ultralytics import YOLO
from tensorflow.keras.models import load_model
from skimage import transform
from skimage import exposure
import numpy as np
import imutils

# Load the classification model and the label names
print("[INFO] loading classification model....")
classification_model = load_model("bestModel.h5")  # Replace with your model path
labelnames = open("signnames.csv").read().strip().split("\n")[1:]
labelnames = [l.split(",")[1] for l in labelnames]

# Load the YOLOv8 model
yolo_model = YOLO("best.pt")

# Open the video capture
cap = cv2.VideoCapture(2)

# Loop through the video frames
while cap.isOpened():
    # Read a frame from the video
    success, frame = cap.read()

    if success:
        # Run YOLOv8 inference on the frame
        results = yolo_model(frame)
        
        # Iterate over results to extract information
        for result in results:
            # Get bounding boxes in [xmin, ymin, xmax, ymax] format
            boxes = result.boxes.xyxy.cpu().numpy()
        
            # Get class labels
            labels = [yolo_model.names[int(cls)] for cls in result.boxes.cls]
        
            # Get confidence scores
            confidences = result.boxes.conf.cpu().numpy()
        
            # Loop through the detected objects
            for box, label, confidence in zip(boxes, labels, confidences):
                print(f"Box: {box}, Label: {label}, Confidence: {confidence}")
                
                # Extract bounding box coordinates and ensure they are valid
                xmin, ymin, xmax, ymax = map(int, box)
                
                # Ensure the ROI dimensions are valid
                if xmax > xmin and ymax > ymin:
                    # Crop the Region of Interest (ROI)
                    roi = frame[ymin:ymax, xmin:xmax]

                    # Ensure the ROI is not empty
                    if roi.size > 0:
                        try:
                            # Resize the ROI for classification
                            roi_resized = cv2.resize(roi, (32, 32))

                            # Apply contrast adjustment
                            roi_resized = exposure.equalize_adapthist(roi_resized, clip_limit=0.1)
                            roi_resized = roi_resized.astype("float") / 255.0
                            roi_resized = np.expand_dims(roi_resized, axis=0)

                            # Predict the label for the ROI
                            preds = classification_model.predict(roi_resized)
                            j = preds.argmax(axis=1)[0]
                            sign_label = labelnames[j]
                            print(f"Predicted Label: {sign_label}")

                            # Display the cropped ROI in a new window
                            #cv2.imshow(f"ROI - {sign_label}", roi)
                        except Exception as e:
                            print(f"Error processing ROI: {e}")
                else:
                    print("Invalid bounding box dimensions")

        # Visualize the results on the frame
        annotated_frame = results[0].plot()

        # Display the annotated frame
        cv2.imshow("YOLOv8 Inference", annotated_frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    else:
        # Break the loop if the end of the video is reached
        break

# Release the video capture object and close the display window
cap.release()
cv2.destroyAllWindows()
