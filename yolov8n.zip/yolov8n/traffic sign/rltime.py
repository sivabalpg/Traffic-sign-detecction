from tensorflow.keras.models import load_model
from skimage import transform
from skimage import exposure
import numpy as np
import cv2
import imutils

# Load the model and the label names
print("[INFO] loading model....")
model = load_model("bestModel.h5")  # Replace with your model path
labelnames = open("signnames.csv").read().strip().split("\n")[1:]
labelnames = [l.split(",")[1] for l in labelnames]

# Initialize the video stream
print("[INFO] starting video stream...")
cap = cv2.VideoCapture(0)  # Use 0 for default webcam. Change if you have multiple cameras.

while True:
    ret, frame = cap.read()
    
    if not ret:
        print("[ERROR] Can't access the camera feed!")
        break
    
    # Preprocess the frame for prediction
    output_frame = frame.copy()  # Make a copy of the frame for output
    frame = cv2.resize(frame, (32, 32))
    frame = exposure.equalize_adapthist(frame, clip_limit=0.1)
    frame = frame.astype("float") / 255.0
    frame = np.expand_dims(frame, axis=0)
    
    # Predict the label
    preds = model.predict(frame)
    j = preds.argmax(axis=1)[0]
    label = labelnames[j]

    # Display the label on the output frame
    output_frame = imutils.resize(output_frame, width=400)
    cv2.putText(output_frame, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                0.8, (0, 255, 0), 2)
    
    # Show the output frame
    cv2.imshow("Traffic Sign Recognition", output_frame)
    
    # If 'q' is pressed, exit the loop
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
cap.release()
cv2.destroyAllWindows()
